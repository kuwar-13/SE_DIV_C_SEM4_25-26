from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import or_
from datetime import datetime, timedelta

app = Flask(__name__)

# Session ke liye secret key
app.secret_key = 'change_this_secret_key'

# ====== DATABASE CONFIG (MySQL) ======
# MySQL username: root
# MySQL password: 13022006
# Database: ro_service_db
# LOCAL MySQL ke liye ye use kiya tha:
# app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:13022006@localhost/ro_service_db'
# DEPLOYMENT (PythonAnywhere) + simple setup ke liye SQLite:
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ro_service.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# ====== MODELS ======

class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='customer')  # customer / staff / technician / admin

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Sale(db.Model):
    __tablename__ = 'sales'

    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    staff_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    product_name = db.Column(db.String(150), nullable=False)
    sale_date = db.Column(db.Date, nullable=False)
    payment_method = db.Column(db.String(20), nullable=False)  # Cash / Online / Other
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    customer = db.relationship('User', foreign_keys=[customer_id], backref='purchases')
    staff = db.relationship('User', foreign_keys=[staff_id], backref='sales_made')


class ServiceRequest(db.Model):
    __tablename__ = 'service_requests'

    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    technician_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    product_name = db.Column(db.String(150), nullable=False)
    problem_type = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=False)
    preferred_date = db.Column(db.Date, nullable=False)
    service_type = db.Column(db.String(10), nullable=False, default='Paid')  # Free / Paid
    status = db.Column(db.String(20), nullable=False, default='Pending')    # Pending / Assigned / In Progress / Completed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    customer = db.relationship('User', foreign_keys=[customer_id], backref='service_requests')
    technician = db.relationship('User', foreign_keys=[technician_id], backref='assigned_services')


# ====== HELPERS ======

def determine_service_type(customer_id, product_name, request_date):
    """
    1-year warranty + max 3 free services per product.
    request_date: jis date pe service chahiye (preferred_date).
    """

    # Latest sale for this customer & product
    sale = (Sale.query
            .filter_by(customer_id=customer_id, product_name=product_name)
            .order_by(Sale.sale_date.desc())
            .first())
    if not sale:
        return 'Paid'

    # Warranty period: 1 year from sale date
    if (request_date - sale.sale_date).days > 365:
        return 'Paid'

    one_year_later = sale.sale_date + timedelta(days=365)

    # Count previous Free services for this product within 1 year of sale
    free_count = ServiceRequest.query.filter(
        ServiceRequest.customer_id == customer_id,
        ServiceRequest.product_name == product_name,
        ServiceRequest.service_type == 'Free',
        ServiceRequest.created_at >= sale.sale_date,
        ServiceRequest.created_at <= one_year_later
    ).count()

    if free_count >= 3:
        return 'Paid'

    return 'Free'


def staff_required():
    return 'user_id' in session and session.get('user_role') == 'staff'


def technician_required():
    return 'user_id' in session and session.get('user_role') == 'technician'


def admin_required():
    return 'user_id' in session and session.get('user_role') == 'admin'


# ====== ROUTES ======

# Home → direct login
@app.route('/')
def home():
    return redirect(url_for('login'))


# --------- REGISTER (multi-role + existing customer activation) ---------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        role = request.form.get('role', 'customer')
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        address = request.form.get('address')
        password = request.form.get('password')

        # Password backend validation (min 6 chars)
        if not password or len(password) < 6:
            return "Password kam se kam 6 characters ka hona chahiye. <a href='/register'>Wapas jao</a>"

        # Role safe check
        if role not in ['customer', 'staff', 'technician', 'admin']:
            role = 'customer'

        # Check existing email
        existing_user = User.query.filter_by(email=email).first()

        if existing_user:
            # Agar ye customer hi hai (jo staff ne pehle se banaya tha), to usko "activate" karne do
            if existing_user.role == 'customer' and role == 'customer':
                existing_user.name = name
                existing_user.phone = phone
                existing_user.address = address
                existing_user.set_password(password)
                db.session.commit()
                return render_template('register_success.html')
            else:
                return "Ye email kisi aur role ke liye registered hai. <a href='/login'>Login karo</a>"

        # Otherwise: bilkul naya user
        user = User(
            name=name,
            email=email,
            phone=phone,
            address=address,
            role=role
        )
        user.set_password(password)

        db.session.add(user)
        db.session.commit()

        return render_template('register_success.html')

    return render_template('register.html')


# --------- LOGIN (email/phone + password, DB role se redirect) ---------
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None

    if request.method == 'POST':
        identifier = request.form.get('identifier')  # email ya phone
        password = request.form.get('password')

        # Email ya phone se user dhundho
        user = User.query.filter(
            or_(User.email == identifier, User.phone == identifier)
        ).first()

        # Agar user nahi mila ya password galat hai
        if not user or not user.check_password(password):
            error = "Invalid email / phone or password."
        else:
            # Login success
            session['user_id'] = user.id
            session['user_name'] = user.name
            session['user_role'] = user.role

            # Role ke hisaab se redirect
            if user.role == 'customer':
                return redirect(url_for('customer_dashboard'))
            elif user.role == 'staff':
                return redirect(url_for('staff_dashboard'))
            elif user.role == 'technician':
                return redirect(url_for('technician_dashboard'))
            elif user.role == 'admin':
                return redirect(url_for('admin_dashboard'))
            else:
                error = "Unknown role for this user."

    # GET request ya error case – login page render with error (if any)
    return render_template('login.html', error=error)

# --------- LOGOUT ---------
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


# ================== CUSTOMER PART ==================

@app.route('/customer/dashboard')
def customer_dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if session.get('user_role') != 'customer':
        return redirect(url_for('login'))

    user = User.query.get(session['user_id'])
    if not user:
        return redirect(url_for('login'))

    # 1) My Products → Sale table se laao
    sales = Sale.query.filter_by(customer_id=user.id).order_by(Sale.sale_date.desc()).all()
    today = datetime.utcnow().date()

    ro_products = []
    overall_free_total = 0
    overall_free_used = 0

    for s in sales:
        purchase_date = s.sale_date
        warranty_end_date = purchase_date + timedelta(days=365)

        free_total = 3  # per sale/year
        free_used_for_product = ServiceRequest.query.filter_by(
            customer_id=user.id,
            product_name=s.product_name,
            service_type='Free'
        ).count()
        free_remaining_for_product = max(free_total - free_used_for_product, 0)

        under_warranty = today <= warranty_end_date
        can_free_now = under_warranty and free_remaining_for_product > 0

        ro_products.append({
            "name": s.product_name,
            "model": "",
            "purchase_date": purchase_date.strftime('%Y-%m-%d'),
            "warranty_end": warranty_end_date.strftime('%Y-%m-%d'),
            "free_total": free_total,
            "free_used": free_used_for_product,
            "free_remaining": free_remaining_for_product,
            "under_warranty": under_warranty,
            "can_free_now": can_free_now,
            "from_our_shop": True
        })

        overall_free_total += free_total
        overall_free_used += free_used_for_product

    from_our_shop = True if sales else False

    # 2) Total free services summary
    free_services_total = overall_free_total
    free_services_used = overall_free_used
    free_services_remaining = max(free_services_total - free_services_used, 0)

    # 3) Service history
    service_history = []
    requests = ServiceRequest.query.filter_by(customer_id=user.id).order_by(ServiceRequest.created_at.desc()).all()
    for r in requests:
        service_history.append({
            "date": r.created_at.date(),
            "product_name": r.product_name,
            "problem": r.problem_type,
            "service_type": r.service_type,
            "status": r.status
        })

    return render_template(
        'customer_dashboard.html',
        customer_name=user.name,
        customer_email=user.email,
        customer_phone=user.phone,
        customer_address=user.address,
        ro_products=ro_products,
        from_our_shop=from_our_shop,
        free_services_total=free_services_total,
        free_services_used=free_services_used,
        free_services_remaining=free_services_remaining,
        service_history=service_history
    )


@app.route('/customer/update_profile', methods=['POST'])
def update_profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if session.get('user_role') != 'customer':
        return redirect(url_for('login'))

    user = User.query.get(session['user_id'])
    if not user:
        return redirect(url_for('login'))

    user.name = request.form.get('name')
    user.phone = request.form.get('phone')
    user.address = request.form.get('address')

    db.session.commit()
    session['user_name'] = user.name

    return redirect(url_for('customer_dashboard'))


# --------- CUSTOMER: NEW SERVICE REQUEST (Free/Paid logic) ---------
@app.route('/customer/request_service', methods=['POST'])
def request_service():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if session.get('user_role') != 'customer':
        return redirect(url_for('login'))

    user = User.query.get(session['user_id'])
    if not user:
        return redirect(url_for('login'))

    product_name = request.form.get('product_name')
    problem_type = request.form.get('problem_type')
    preferred_date_str = request.form.get('preferred_date')
    description = request.form.get('description')

    try:
        preferred_date = datetime.strptime(preferred_date_str, '%Y-%m-%d').date()
    except Exception:
        preferred_date = datetime.utcnow().date()

    # Free / Paid decide karo
    service_type = determine_service_type(user.id, product_name, preferred_date)

    service = ServiceRequest(
        customer_id=user.id,
        product_name=product_name,
        problem_type=problem_type,
        description=description,
        preferred_date=preferred_date,
        service_type=service_type,
        status='Pending'
    )
    db.session.add(service)
    db.session.commit()

    return redirect(url_for('customer_dashboard'))


# ================== STAFF PART ==================

@app.route('/staff/dashboard')
def staff_dashboard():
    if not staff_required():
        return redirect(url_for('login'))

    staff = User.query.get(session['user_id'])

    all_sales = Sale.query.order_by(Sale.created_at.desc()).all()
    technicians = User.query.filter_by(role='technician').order_by(User.name).all()
    customers = User.query.filter_by(role='customer').order_by(User.name).all()
    service_requests = ServiceRequest.query.order_by(ServiceRequest.created_at.desc()).all()

    return render_template(
        'staff_dashboard.html',
        staff=staff,
        sales=all_sales,
        technicians=technicians,
        customers=customers,
        service_requests=service_requests
    )


@app.route('/staff/add_sale', methods=['POST'])
def add_sale():
    if not staff_required():
        return redirect(url_for('login'))

    staff_id = session['user_id']

    customer_name = request.form.get('customer_name')
    customer_email = request.form.get('customer_email')
    customer_phone = request.form.get('customer_phone')
    customer_address = request.form.get('customer_address')
    product_name = request.form.get('product_name')
    sale_date_str = request.form.get('sale_date')
    payment_method = request.form.get('payment_method')

    try:
        sale_date = datetime.strptime(sale_date_str, '%Y-%m-%d').date()
    except Exception:
        sale_date = datetime.utcnow().date()

    # Existing customer find karo (email/phone se)
    customer = User.query.filter(
        or_(User.email == customer_email, User.phone == customer_phone)
    ).filter_by(role='customer').first()

    # Naya customer create karna pade
    if not customer:
        if not customer_address:
            customer_address = "Not provided"

        default_password = (customer_phone[-6:] if customer_phone and len(customer_phone) >= 6 else 'cust1234')

        customer = User(
            name=customer_name,
            email=customer_email,
            phone=customer_phone,
            address=customer_address,
            role='customer'
        )
        customer.set_password(default_password)
        db.session.add(customer)
        db.session.commit()

    # Sale record
    sale = Sale(
        customer_id=customer.id,
        staff_id=staff_id,
        product_name=product_name,
        sale_date=sale_date,
        payment_method=payment_method
    )
    db.session.add(sale)
    db.session.commit()

    return redirect(url_for('staff_dashboard'))


@app.route('/staff/add_technician', methods=['POST'])
def add_technician():
    if not staff_required():
        return redirect(url_for('login'))

    name = request.form.get('tech_name')
    email = request.form.get('tech_email')
    phone = request.form.get('tech_phone')
    address = request.form.get('tech_address')

    if not (name and email and phone):
        return redirect(url_for('staff_dashboard'))

    existing = User.query.filter_by(email=email).first()
    if existing:
        return redirect(url_for('staff_dashboard'))

    default_password = (phone[-6:] if len(phone) >= 6 else 'tech1234')

    tech = User(
        name=name,
        email=email,
        phone=phone,
        address=address or "Not provided",
        role='technician'
    )
    tech.set_password(default_password)
    db.session.add(tech)
    db.session.commit()

    return redirect(url_for('staff_dashboard'))


@app.route('/staff/delete_technician/<int:tech_id>', methods=['POST'])
def delete_technician(tech_id):
    if not staff_required():
        return redirect(url_for('login'))

    tech = User.query.get_or_404(tech_id)

    # Sirf technician ko hi delete karne do
    if tech.role != 'technician':
        return redirect(url_for('staff_dashboard'))

    # Is technician ke saare service requests se technician ko hata do
    services = ServiceRequest.query.filter_by(technician_id=tech.id).all()
    for s in services:
        s.technician_id = None
        if s.status in ['Assigned', 'In Progress']:
            s.status = 'Pending'

    db.session.delete(tech)
    db.session.commit()

    return redirect(url_for('staff_dashboard'))


@app.route('/staff/assign_service/<int:service_id>', methods=['POST'])
def assign_service(service_id):
    if not staff_required():
        return redirect(url_for('login'))

    tech_id = request.form.get('technician_id')
    service = ServiceRequest.query.get_or_404(service_id)

    if tech_id:
        service.technician_id = int(tech_id)
        if service.status == 'Pending':
            service.status = 'Assigned'
    else:
        service.technician_id = None
    db.session.commit()
    return redirect(url_for('staff_dashboard'))


# ================== TECHNICIAN PART ==================

@app.route('/technician/dashboard')
def technician_dashboard():
    if not technician_required():
        return redirect(url_for('login'))

    tech = User.query.get(session['user_id'])
    if not tech:
        return redirect(url_for('login'))

    tickets = ServiceRequest.query.filter_by(
        technician_id=tech.id
    ).order_by(ServiceRequest.created_at.desc()).all()

    return render_template(
        'technician_dashboard.html',
        tech=tech,
        tickets=tickets
    )


@app.route('/technician/update_service/<int:service_id>', methods=['POST'])
def technician_update_service(service_id):
    if not technician_required():
        return redirect(url_for('login'))

    service = ServiceRequest.query.get_or_404(service_id)
    if service.technician_id != session['user_id']:
        return redirect(url_for('technician_dashboard'))

    new_status = request.form.get('status')
    if new_status in ['Pending', 'Assigned', 'In Progress', 'Completed']:
        service.status = new_status
        db.session.commit()

    return redirect(url_for('technician_dashboard'))


@app.route('/technician/update_profile', methods=['POST'])
def technician_update_profile():
    if not technician_required():
        return redirect(url_for('login'))

    tech = User.query.get(session['user_id'])
    if not tech:
        return redirect(url_for('login'))

    tech.phone = request.form.get('phone')
    tech.address = request.form.get('address')
    new_password = request.form.get('password')

    if new_password and len(new_password) >= 6:
        tech.set_password(new_password)

    db.session.commit()

    return redirect(url_for('technician_dashboard'))


# ================== ADMIN PART ==================

@app.route('/admin/dashboard')
def admin_dashboard():
    if not admin_required():
        return redirect(url_for('login'))

    admin = User.query.get(session['user_id'])
    if not admin:
        return redirect(url_for('login'))

    # User counts
    total_users = User.query.count()
    total_customers = User.query.filter_by(role='customer').count()
    total_staff = User.query.filter_by(role='staff').count()
    total_technicians = User.query.filter_by(role='technician').count()
    total_admins = User.query.filter_by(role='admin').count()

    # Service request counts
    total_services = ServiceRequest.query.count()
    pending_count = ServiceRequest.query.filter_by(status='Pending').count()
    assigned_count = ServiceRequest.query.filter_by(status='Assigned').count()
    inprog_count = ServiceRequest.query.filter_by(status='In Progress').count()
    completed_count = ServiceRequest.query.filter_by(status='Completed').count()

    # Sales count
    total_sales = Sale.query.count()

    # Latest service requests (10)
    latest_services = ServiceRequest.query.order_by(ServiceRequest.created_at.desc()).limit(10).all()
    service_requests = ServiceRequest.query.order_by(ServiceRequest.created_at.desc()).all()

    # Users by role
    customers = User.query.filter_by(role='customer').order_by(User.name).all()
    staff_users = User.query.filter_by(role='staff').order_by(User.name).all()
    technicians = User.query.filter_by(role='technician').order_by(User.name).all()
    admins = User.query.filter_by(role='admin').order_by(User.name).all()

    return render_template(
        'admin_dashboard.html',
        admin=admin,
        total_users=total_users,
        total_customers=total_customers,
        total_staff=total_staff,
        total_technicians=total_technicians,
        total_admins=total_admins,
        total_services=total_services,
        pending_count=pending_count,
        assigned_count=assigned_count,
        inprog_count=inprog_count,
        completed_count=completed_count,
        total_sales=total_sales,
        latest_services=latest_services,
        service_requests=service_requests,
        customers=customers,
        staff_users=staff_users,
        technicians=technicians,
        admins=admins
    )


# # ====== MAIN ======
# if __name__ == '__main__':
#     with app.app_context():
#         db.create_all()
#     app.run(debug=True)

# ====== MAIN ======
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, host='0.0.0.0')