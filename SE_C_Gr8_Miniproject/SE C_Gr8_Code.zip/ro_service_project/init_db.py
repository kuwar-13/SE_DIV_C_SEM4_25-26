# WARNING: Dev-only script. Run only when DB/tables need to be recreated.
from app import app, db

# Yahaan se Flask app ka context le kar saare tables create karenge
with app.app_context():
    db.create_all()
    print("Tables created successfully in ro_service_db.")